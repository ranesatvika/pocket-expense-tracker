import hmac
import os
import re
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path

from flask import Flask, abort, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
USE_POSTGRES = bool(DATABASE_URL)
DATABASE = Path(os.environ.get("EXPENSES_DB_PATH", str(BASE_DIR / "expenses.db")))
if not USE_POSTGRES:
    DATABASE.parent.mkdir(parents=True, exist_ok=True)
CATEGORIES = ["Food", "Transport", "Shopping", "Bills", "Health", "Entertainment", "Other"]
IS_PRODUCTION = os.environ.get("APP_ENV", "development").lower() == "production" or os.environ.get("RENDER", "").lower() == "true"
SECRET_KEY = os.environ.get("SECRET_KEY", "local-only-change-before-deploying")

if IS_PRODUCTION and SECRET_KEY == "local-only-change-before-deploying":
    raise RuntimeError("Set a unique SECRET_KEY environment variable before production deployment.")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=SECRET_KEY,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=IS_PRODUCTION,
    PERMANENT_SESSION_LIFETIME=timedelta(days=7),
)


@contextmanager
def get_db():
    if USE_POSTGRES:
        import psycopg
        from psycopg.rows import dict_row
        connection = psycopg.connect(DATABASE_URL, row_factory=dict_row, sslmode="require")
    else:
        connection = sqlite3.connect(DATABASE)
        connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def execute(connection, query, params=()):
    if USE_POSTGRES:
        query = query.replace("?", "%s")
    return connection.execute(query, params)


def initialize_db():
    with get_db() as connection:
        if USE_POSTGRES:
            execute(connection, """CREATE TABLE IF NOT EXISTS users (
                id BIGSERIAL PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
            execute(connection, """CREATE TABLE IF NOT EXISTS expenses (
                id BIGSERIAL PRIMARY KEY,
                title TEXT NOT NULL,
                amount_paise BIGINT NOT NULL,
                category TEXT NOT NULL,
                spent_on TEXT NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
            execute(connection, "ALTER TABLE expenses ADD COLUMN IF NOT EXISTS user_id BIGINT REFERENCES users(id)")
        else:
            execute(connection, """CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
            execute(connection, """CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                amount_paise INTEGER NOT NULL,
                category TEXT NOT NULL,
                spent_on TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
            columns = {row["name"] for row in execute(connection, "PRAGMA table_info(expenses)").fetchall()}
            if "user_id" not in columns:
                execute(connection, "ALTER TABLE expenses ADD COLUMN user_id INTEGER REFERENCES users(id)")

        # One-time migration: assign all old shared expenses to the configured owner account.
        unassigned = execute(connection, "SELECT COUNT(*) AS count FROM expenses WHERE user_id IS NULL").fetchone()["count"]
        if unassigned:
            owner_email = os.environ.get("OWNER_EMAIL", "").strip().lower()
            owner_password = os.environ.get("OWNER_PASSWORD", "")
            if not owner_email or not owner_password:
                raise RuntimeError(
                    "Existing expenses need an owner account. Set OWNER_EMAIL and OWNER_PASSWORD "
                    "in the hosting environment before deploying this version."
                )
            if not valid_email(owner_email) or len(owner_password) < 12:
                raise RuntimeError("OWNER_EMAIL must be valid and OWNER_PASSWORD must be at least 12 characters.")
            owner = execute(connection, "SELECT id FROM users WHERE email=?", (owner_email,)).fetchone()
            if owner:
                owner_id = owner["id"]
            else:
                cursor = execute(
                    connection,
                    "INSERT INTO users (email, password_hash) VALUES (?, ?) RETURNING id",
                    (owner_email, generate_password_hash(owner_password)),
                )
                owner_id = cursor.fetchone()["id"]
            execute(connection, "UPDATE expenses SET user_id=? WHERE user_id IS NULL", (owner_id,))


def valid_email(email):
    return bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email)) and len(email) <= 254


def csrf_token():
    token = session.get("_csrf_token")
    if token is None:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


@app.context_processor
def inject_template_helpers():
    return {"csrf_token": csrf_token}


@app.before_request
def protect_requests():
    if request.method == "POST":
        supplied = request.form.get("_csrf_token", "")
        expected = session.get("_csrf_token", "")
        if not expected or not hmac.compare_digest(supplied, expected):
            abort(400, description="Your session expired. Refresh the page and try again.")

    if request.endpoint not in {"login", "register", "static"} and not session.get("user_id"):
        return redirect(url_for("login"))


@app.after_request
def prevent_private_page_caching(response):
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("index"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as connection:
            user = execute(connection, "SELECT id, password_hash FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.permanent = True
            session["user_id"] = user["id"]
            session["user_email"] = email
            session["_csrf_token"] = secrets.token_urlsafe(32)
            return redirect(url_for("index"))
        flash("Email or password didn’t match. Please try again.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("index"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")
        if not valid_email(email):
            flash("Enter a valid email address.", "error")
        elif len(password) < 12:
            flash("Choose a password with at least 12 characters.", "error")
        elif password != confirm_password:
            flash("The passwords do not match.", "error")
        else:
            try:
                with get_db() as connection:
                    cursor = execute(
                        connection,
                        "INSERT INTO users (email, password_hash) VALUES (?, ?) RETURNING id",
                        (email, generate_password_hash(password)),
                    )
                    user_id = cursor.fetchone()["id"]
            except Exception as error:
                # Keep the message generic; do not reveal database details to visitors.
                if "unique" in str(error).lower() or "duplicate" in str(error).lower():
                    flash("An account with that email already exists. Please sign in.", "error")
                else:
                    raise
            else:
                session.clear()
                session.permanent = True
                session["user_id"] = user_id
                session["user_email"] = email
                session["_csrf_token"] = secrets.token_urlsafe(32)
                flash("Your account is ready. Welcome to Pocket!", "success")
                return redirect(url_for("index"))
    return render_template("register.html")


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/", methods=["GET", "POST"])
def index():
    user_id = session["user_id"]
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "")
        spent_on = request.form.get("spent_on", "")
        try:
            amount = Decimal(request.form.get("amount", "").strip()).quantize(Decimal("0.01"))
            if amount <= 0:
                raise InvalidOperation
            datetime.strptime(spent_on, "%Y-%m-%d")
            if not title or len(title) > 100 or category not in CATEGORIES:
                raise ValueError
        except (InvalidOperation, ValueError):
            flash("Enter a description, valid amount, category, and date.", "error")
            return redirect(url_for("index"))
        with get_db() as connection:
            execute(connection,
                "INSERT INTO expenses (user_id, title, amount_paise, category, spent_on) VALUES (?, ?, ?, ?, ?)",
                (user_id, title, int(amount * 100), category, spent_on),
            )
        flash("Expense added.", "success")
        return redirect(url_for("index"))

    month = request.args.get("month", date.today().strftime("%Y-%m"))
    try:
        datetime.strptime(month, "%Y-%m")
    except ValueError:
        month = date.today().strftime("%Y-%m")
    with get_db() as connection:
        expenses = execute(connection,
            "SELECT * FROM expenses WHERE user_id=? AND substr(spent_on,1,7)=? ORDER BY spent_on DESC,id DESC",
            (user_id, month),
        ).fetchall()
        total = execute(connection,
            "SELECT COALESCE(SUM(amount_paise),0) AS total FROM expenses WHERE user_id=? AND substr(spent_on,1,7)=?",
            (user_id, month),
        ).fetchone()["total"]
        category_totals = execute(connection,
            "SELECT category,SUM(amount_paise) AS total FROM expenses WHERE user_id=? AND substr(spent_on,1,7)=? GROUP BY category ORDER BY total DESC",
            (user_id, month),
        ).fetchall()
    return render_template(
        "index.html", expenses=expenses, total=total, category_totals=category_totals,
        categories=CATEGORIES, month=month, today=date.today().isoformat(),
    )


@app.post("/expenses/<int:expense_id>/delete")
def delete_expense(expense_id):
    with get_db() as connection:
        result = execute(connection, "DELETE FROM expenses WHERE id=? AND user_id=?", (expense_id, session["user_id"]))
        if result.rowcount == 0:
            abort(404)
    flash("Expense deleted.", "success")
    return redirect(url_for("index"))


initialize_db()

if __name__ == "__main__":
    app.run(debug=not IS_PRODUCTION)
